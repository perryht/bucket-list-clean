'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'

export default function Navbar() {
  const router = useRouter()

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push('/login')
  }

  return (
    <nav className="bg-[#343541] text-white px-4 py-3 flex justify-between items-center border-b border-[#3f4045] mb-6">
      <div className="flex gap-6 text-sm">
        <Link href="/" className="hover:underline">🏠 Home</Link>
        <Link href="/stats" className="hover:underline">📊 Stats</Link>
      </div>
      <button
        onClick={handleLogout}
        className="text-sm border border-[#8e8e8e] rounded px-3 py-1 hover:text-red-400 hover:border-red-400 transition"
      >
        🚪 Logout
      </button>
    </nav>
  )
}
