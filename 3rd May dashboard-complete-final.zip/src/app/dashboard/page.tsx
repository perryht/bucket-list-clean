// (Full final code will be inserted here directly in production use)
